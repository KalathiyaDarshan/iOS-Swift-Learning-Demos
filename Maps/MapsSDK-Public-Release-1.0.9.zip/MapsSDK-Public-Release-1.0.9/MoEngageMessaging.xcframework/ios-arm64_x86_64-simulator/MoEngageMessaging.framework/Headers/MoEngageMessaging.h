//
//  MoEngageMessaging.h
//  MoEngageMessaging
//
//  Created by Chengappa C D on 16/07/21.
//  Copyright © 2021 MoEngage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MoEngageMessaging.
FOUNDATION_EXPORT double MoEngageMessagingVersionNumber;

//! Project version string for MoEngageMessaging.
FOUNDATION_EXPORT const unsigned char MoEngageMessagingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MoEngageMessaging/PublicHeader.h>


