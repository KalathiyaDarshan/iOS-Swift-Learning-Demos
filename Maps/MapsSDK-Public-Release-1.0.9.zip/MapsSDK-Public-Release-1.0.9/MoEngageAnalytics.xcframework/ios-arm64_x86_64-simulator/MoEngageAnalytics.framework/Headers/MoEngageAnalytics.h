//
//  MoEngageAnalytics.h
//  MoEngageAnalytics
//
//  Created by Chengappa C D on 01/06/21.
//  Copyright © 2021 MoEngage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MoEngageAnalytics.
FOUNDATION_EXPORT double MoEngageAnalyticsVersionNumber;

//! Project version string for MoEngageAnalytics.
FOUNDATION_EXPORT const unsigned char MoEngageAnalyticsVersionString[];


