//
//  MoEngageSecurity.h
//  MoEngageSecurity
//
//  Created by Rakshitha on 14/04/23.
//  Copyright © 2023 MoEngage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MoEngageSecurity.
FOUNDATION_EXPORT double MoEngageSecurityVersionNumber;

//! Project version string for MoEngageSecurity.
FOUNDATION_EXPORT const unsigned char MoEngageSecurityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MoEngageSecurity/PublicHeader.h>


