//
//  MoEngageCoreTvOS.h
//  MoEngageCoreTvOS
//
//  Created by Rakshitha on 10/02/22.
//  Copyright © 2022 MoEngage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MoEngageCoreTvOS.
FOUNDATION_EXPORT double MoEngageCoreTvOSVersionNumber;

//! Project version string for MoEngageCoreTvOS.
FOUNDATION_EXPORT const unsigned char MoEngageCoreTvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MoEngageCoreTvOS/PublicHeader.h>


#import <MoEngageCore/MoEngageInAppDelegate.h>
