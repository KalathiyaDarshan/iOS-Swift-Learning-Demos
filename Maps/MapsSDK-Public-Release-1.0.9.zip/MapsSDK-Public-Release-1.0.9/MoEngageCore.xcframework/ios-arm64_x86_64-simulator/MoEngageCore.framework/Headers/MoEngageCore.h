//
//  MoEngageCore.h
//  MoEngageCore
//
//  Created by Chengappa C D on 10/03/21.
//  Copyright © 2021 MoEngage. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MoEngageCore.
FOUNDATION_EXPORT double MOCoreVersionNumber;

//! Project version string for MoEngageCore.
FOUNDATION_EXPORT const unsigned char MOCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like



#import <MoEngageCore/MoEngageInAppDelegate.h>
