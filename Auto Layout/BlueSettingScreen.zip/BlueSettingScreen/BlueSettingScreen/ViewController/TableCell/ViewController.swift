//
//  ViewController.swift
//  BlueSettingScreen
//
//  Created by Darshan Kalathiya on 19/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

