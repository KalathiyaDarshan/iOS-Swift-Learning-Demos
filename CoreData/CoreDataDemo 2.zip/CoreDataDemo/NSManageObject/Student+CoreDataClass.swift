//
//  Student+CoreDataClass.swift
//  CoreDataDemo
//
//  Created by mac on 03/09/24.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
