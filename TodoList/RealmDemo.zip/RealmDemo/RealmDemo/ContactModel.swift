//
//  ContactModel.swift
//  RealmDemo
//
//  Created by mac on 11/09/24.
//

import Foundation

class Contact{
    var firstName: String
    var lastName: String
    
    init(firstName: String,lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
}
