//
//  Secondview.swift
//  navigation&segue
//
//  Created by mac on 16/05/24.
//

import UIKit

class Secondview: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
