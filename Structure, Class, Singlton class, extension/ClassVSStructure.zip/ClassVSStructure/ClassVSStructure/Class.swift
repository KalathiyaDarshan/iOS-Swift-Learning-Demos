//
//  Class.swift
//  ClassVSStructure
//
//  Created by mac on 31/07/24.
//

import Foundation

class UserClass{
    var id: Int
    var name, email : String
    
    init(id: Int,name: String,email: String) {
        self.id = id
        self.name = name
        self.email = email
    }
}
