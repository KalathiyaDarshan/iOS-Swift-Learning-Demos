//
//  Structure.swift
//  ClassVSStructure
//
//  Created by mac on 31/07/24.
//

import Foundation

struct UserStructure {
    var  id: Int
    var name, email: String
}
