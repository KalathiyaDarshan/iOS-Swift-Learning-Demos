//
//  DemoClass.swift
//  xibAddView
//
//  Created by Apple on 23/10/24.
//

import Foundation

class Demo{
    var title: String
    var discription: [Discription]
    
    init(title: String,discription: [Discription]) {
        self.title = title
        self.discription = discription
    }
}
