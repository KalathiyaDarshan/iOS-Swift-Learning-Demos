//
//  Discription.swift
//  xibAddView
//
//  Created by Apple on 23/10/24.
//

import Foundation

class Discription{
    var discription: String
    
    init(discription: String) {
        self.discription = discription
    }
}
