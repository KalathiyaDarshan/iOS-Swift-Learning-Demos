//
//  TheredViewController.swift
//  MultipalStroybord
//
//  Created by mac on 17/05/24.
//

import UIKit

class TheredViewController: UIViewController {

    @IBOutlet var lblThred: UILabel!
    var labelThered: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        lblThred.text = labelThered
       
    }
    

   

}
