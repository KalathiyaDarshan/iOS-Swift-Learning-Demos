//
//  BaseVC.swift
//  Blue
//
//  Created by Blue.

import UIKit

class BaseVC: UIViewController {
    
    // ----------------------------------------------------------
    //                       MARK: - Property -
    // ----------------------------------------------------------
    static let sharedInstance = BaseVC()
    
}
