//
//  TourScreen1ViewController.swift
//  Blue
//
//  Created by Blue.

import UIKit
//import Lottie

class TourScreen1ViewController: BaseVC {
    
    // ----------------------------------------------------------
    //                       MARK: - Outlet -
    // ----------------------------------------------------------
    @IBOutlet weak var videoView                    : UIView!
    @IBOutlet weak var gradientColorView            : CustomView!
    
    // ----------------------------------------------------------
    //                       MARK: - Property -
    // ----------------------------------------------------------

    // ----------------------------------------------------------
    //                       MARK: - View Life Cycle -
    // ----------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
