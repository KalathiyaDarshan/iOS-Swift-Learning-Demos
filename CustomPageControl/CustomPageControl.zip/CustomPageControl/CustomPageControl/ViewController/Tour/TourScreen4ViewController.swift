//
//  TourScreen4ViewController.swift
//  Blue
//
//  Created by Blue.

import UIKit
import AVFoundation

class TourScreen4ViewController: BaseVC {
    
    // ----------------------------------------------------------
    //                       MARK: - Outlet -
    // ----------------------------------------------------------
    @IBOutlet weak var videoView            : UIView!
    @IBOutlet weak var gradientColorView    : UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
