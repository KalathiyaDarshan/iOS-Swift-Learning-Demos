//
//  TourScreen3ViewController.swift
//  Blue
//
//  Created by Blue.

import UIKit
import AVFoundation

class TourScreen3ViewController: BaseVC {
    
    // ----------------------------------------------------------
    //                       MARK: - Outlet -
    // ----------------------------------------------------------
    @IBOutlet weak var videoView            : UIView!
    @IBOutlet weak var gradientColorView    : UIView!
    

    // ----------------------------------------------------------
    //                       MARK: - View Life Cycle -
    // ----------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
