//
//  SecondVC.swift
//  ThemeChange
//
//  Created by Darshan Kalathiya on 18/12/24.
//

import UIKit

class SecondVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
