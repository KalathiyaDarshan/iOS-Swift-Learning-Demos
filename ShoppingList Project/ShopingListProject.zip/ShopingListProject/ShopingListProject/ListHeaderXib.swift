//
//  ListHeaderXib.swift
//  ShopingListProject
//
//  Created by mac on 19/06/24.
//

import UIKit

class ListHeaderXib: UITableViewHeaderFooterView {
    
    

}
