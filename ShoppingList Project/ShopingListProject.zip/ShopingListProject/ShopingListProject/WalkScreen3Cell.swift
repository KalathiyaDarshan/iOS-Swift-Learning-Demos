//
//  WalkScreen3Cell.swift
//  ShopingListProject
//
//  Created by mac on 18/06/24.
//

import UIKit

class WalkScreen3Cell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
