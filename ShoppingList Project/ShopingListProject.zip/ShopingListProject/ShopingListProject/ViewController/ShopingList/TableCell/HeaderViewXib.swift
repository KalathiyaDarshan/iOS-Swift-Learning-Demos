//
//  HeaderViewXib.swift
//  ShopingListProject
//
//  Created by mac on 19/06/24.
//

import UIKit

class HeaderViewXib: UITableViewHeaderFooterView {
    @IBOutlet var lblHeader: UILabel!
    @IBOutlet var lblCount: UILabel!
    
    
    @IBAction func dropDownAction(_ sender: UIButton) {
       
    }
    
}
