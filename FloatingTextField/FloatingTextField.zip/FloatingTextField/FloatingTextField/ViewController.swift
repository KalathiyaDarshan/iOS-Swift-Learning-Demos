//
//  ViewController.swift
//  FloatingTextField
//
//  Created by Apple on 02/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

