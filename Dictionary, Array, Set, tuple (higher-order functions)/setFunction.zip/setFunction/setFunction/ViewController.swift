//
//  ViewController.swift
//  setFunction
//
//  Created by mac on 14/05/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        array()
        set()
        Dictionary()
    }
    func array(){
        print("Array Example")
        var numbers: [Int] = [1, 2, 3, 4, 5]
        
        let sum = numbers.reduce(0,+)
        print("Reduce ",sum) //

        numbers.append(6)
        print("append 6 \(numbers)") //Single element add in last
        
        numbers.append(contentsOf: [7,8])
        print("append contentsOf \(numbers)")  // Multipall element add in last
        
        
        numbers.insert(0, at: 0)
        print("insert 0 \(numbers)")  // Add element in specific index
        
        numbers.insert(contentsOf: [9,10], at: 9) // multipal element add in specific index
        print("insert contentsOf \(numbers)")
        
        print(numbers.contains(110)) // return bool value
        
        print("dropFirs \(numbers.dropFirst(2))") // remove first side elements
        
        print("dropLast \(numbers.dropLast(2))") // remove last side elements
        
        print(numbers.min())
        
        numbers.remove(at: 10)
        print("remove \(numbers)") // remove specific element
        
        //numbers.removeAll()
        //print("Remove All \(numbers)") // remove all elements
        
        numbers.removeSubrange(2...4)
        print("removeSubrange ",numbers)
        
         numbers.reverse()
        print("Reverse Array",numbers)
        
        numbers.sort()
        print("Sort ",numbers)
        
        numbers.swapAt(0, 6)
        print("Swap ",numbers)
        
        print(numbers.allSatisfy{$0 is Int})
        print("filter ",numbers.filter{$0 is Int})
        
        print(numbers.map{ $0 + 2})
        

        numbers.forEach{ number in
              print("numbers ",number)
        }
        
        let arrayOfArrays = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]
        
        let flattenedArray = arrayOfArrays.flatMap{$0}
        print("flat Map ",flattenedArray)

        var num = [1, 4, 5, nil, nil]
        print("Compact map ",num.compactMap { $0 }) // remove nil value

        var num1 = ["1", "4", "5", "One", "two"]
        print("Compact map ",num1.compactMap{Int($0)})
        
                var string: [String] = ["Hello", "my", "Name" , "is", "Darshan"]
        
        print(string.joined(separator: " ")) // join all array in a one string
      
    }
    func set(){
        print("Set Example")
        let numbers: Set<Int> = [1, 2, 3, 4,5]
        let numbers1: Set = [1, 2, 3, 4,5,nil]
       
        print(numbers.map{$0 * 2 })
        print(numbers1.compactMap{$0})
        print(numbers.reduce(1 , *))
        print(numbers.contains(5))
        print(numbers.filter{$0 is Int})
        numbers.forEach{value in
            print("set vallue \(value)")
        }
        print(numbers.sorted())
        print(numbers)
    }
    
    func Dictionary()
    {
        print("Dictionary")
        let Dictionary = ["a": 1,"b": 2, "c": 3,"d":4,"e":5]
        
        print(Dictionary.mapValues{$0 * 2})
       
        let Dictionary1 = ["a": 1,"b": 2, "c": 3,"d":4,"e":5,"f" :nil]
        print(Dictionary1.compactMapValues{$0})
        
        var Dictionary2 = ["a": 1,"b": 2, "c": 3,"d": 4]
        let sum = Dictionary2.reduce(0) {$0 + $1.value}
        print(sum)
        print(Dictionary)
        print(Dictionary.contains{$0.key == "a"})
        print(Dictionary.contains{$0.value == 5})
        
        Dictionary.forEach{key, value in
                           print("Key: \(key), Value: \(value)")
        }
        
        for (index, key_value) in Dictionary.enumerated() {
           print("\(index): \(key_value)")
        }
        
        print(Dictionary.filter({ $0.value is Int }))
        
        Dictionary2.updateValue(6, forKey: "e")
        print(Dictionary2)
    }
}

