//
//  SubCategoryCell.swift
//  Collection&Tableview
//
//  Created by mac on 11/06/24.
//

import UIKit

class SubCategoryCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
