//
//  HeaderReusableView.swift
//  Collection&Tableview
//
//  Created by mac on 12/06/24.
//

import UIKit

class HeaderReusableView: UICollectionReusableView {
    @IBOutlet var lblheader: UILabel!
    
}
