//
//  LebelCell.swift
//  ShopingCollectionView
//
//  Created by mac on 07/06/24.
//

import UIKit

class LebelCell: UICollectionViewCell {
    
}
