//
//  MyCellXib.swift
//  TableCellXib
//
//  Created by mac on 04/06/24.
//

import UIKit

class MyCellXib: UITableViewCell {

    @IBOutlet var lblNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
