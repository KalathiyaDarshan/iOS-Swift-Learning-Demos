//
//  NumbersCell.swift
//  CollationView
//
//  Created by mac on 06/06/24.
//

import UIKit

class NumbersCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

}
