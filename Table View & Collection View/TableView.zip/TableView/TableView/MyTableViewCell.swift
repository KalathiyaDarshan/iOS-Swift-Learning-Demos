//
//  MyTableViewCell.swift
//  TableView
//
//  Created by mac on 04/06/24.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    
    @IBOutlet var viewColor: UIView!
    @IBOutlet var lblNumber: UILabel!

}
