//
//  NumbersCell.swift
//  CollectionViewTask
//
//  Created by mac on 06/06/24.
//

import UIKit

class NumbersCell: UICollectionViewCell {

    @IBOutlet var cellView: UIView!
    @IBOutlet var lblNumbers: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    
    
        
    }

}
