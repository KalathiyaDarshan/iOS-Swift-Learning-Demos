//
//  CollectionViewCell.swift
//  ExpandableTableview
//
//  Created by mac on 13/06/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
