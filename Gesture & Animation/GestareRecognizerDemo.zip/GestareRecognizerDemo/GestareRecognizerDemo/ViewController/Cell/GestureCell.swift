//
//  GestureCell.swift
//  GestareRecognizerDemo
//
//  Created by mac on 13/09/24.
//

import UIKit

class GestureCell: UICollectionViewCell {

    @IBOutlet var MainView: UIView!
    @IBOutlet var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

}
