//
//  ImageCell.swift
//  APICollectionDemo
//
//  Created by mac on 25/07/24.
//

import UIKit

class ImageCell: UICollectionViewCell {
    
}
