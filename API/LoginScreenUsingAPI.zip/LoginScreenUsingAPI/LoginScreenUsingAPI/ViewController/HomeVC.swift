//
//  HomeVC.swift
//  APIDemo
//
//  Created by mac on 18/07/24.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
    }
    

    
}
